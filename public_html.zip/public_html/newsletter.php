
<section id="newsletter" class="section-p1 section-m1">
    <div class="newstext">
        <h4>Your One-Stop Destination for Style and Savings!</h4>
        <p>Get updates about our latest <span>special offers.</span></p>
    </div>
    <div class="form">
        <input type="text" placeholder="Shop Smart, Shop Savvy" readonly>
        <button class="normal"><a href="shop.php" style="text-decoration: none; color: white;  ">Explore</a></button>
    </div>
</section>
