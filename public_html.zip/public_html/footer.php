<footer class="section-p1">
		<div class="col">
			<img class="logo" src="img/logo.jpg" alt="" style="width:90px; height: 36px; border-radius: 13px;">
			<h4>Contact</h4>
			<p><strong>Address:</strong>Sheshi Nënë Tereza 4, Tiranë</p>
			<p><strong>Phone:</strong>+355 69 99 99 999</p>
			<p><strong>Hours:</strong> 09:00-21:00,Mon-Sat</p>	
			<div class="follow">
				<h4>Follow us</h4>
				<div class="icon">
					<a href="https://www.fti.edu.al/"><i class="fab fa-facebook-f"></i></a>
					<a href="https://www.fti.edu.al/"><i class="fab fa-linkedin"></i></i></a>
					<a href="https://www.fti.edu.al/"><i class="fab fa-instagram"></i></a>
					<a href="https://www.fti.edu.al/"><i class="fab fa-youtube"></i></a>

				</div>
			</div>
		</div>

		<div class="col">
			<h4>About</h4>
			<a href="shop.php">About</a>
			<a href="contact.php">Contact</a>
			<a href="#">Privacy Policy</a>


		</div>

		<div class="col install">
			<h4>Install App</h4>
			<p>From App Store or Google Play</h4>
			<div class="row">
				<img src="img/pay/app.jpg" alt="">
				<img src="img/pay/play.jpg" alt="">	
			</div>
			<p>Secured Payment Gateways </p>
			<img src="img/pay/pay.png" alt="">
					
		</div>
	</footer>

	