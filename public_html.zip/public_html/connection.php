<?php

	$dbuser="root";
	$dbpass="";
	$dbhost="localhost";
	$dbname="shopping_page";
	$con=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname) OR die ('Please try again');
?>
